
require('./mjs');
require('./bootstrap');

require('alpinejs');
