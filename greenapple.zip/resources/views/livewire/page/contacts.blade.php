<div>
<livewire:layout.navigation/>
<div class="mt-10 pt-10">
<livewire:layout.contacts/>
<div class="bg-gray-100 w-full overflow-hidden">
  <script src="https://apps.elfsight.com/p/platform.js" defer></script>
  <div class="elfsight-app-b7fa309a-6da8-46c8-803e-677e7ae1236e"></div>
</div>
</div>
<!-- l i ve wire :lay out.body/ -->
<livewire:layout.footer/>
</div>
