<div>
  <livewire:layout.navigation/>
  <livewire:layout.touractivities/>
   <livewire:layout.footer/>
</div>
