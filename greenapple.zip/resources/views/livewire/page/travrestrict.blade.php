<div>
  <livewire:layout.navigation/>
  <livewire:page.travelrestriction/>
   <livewire:layout.footer/>
</div>
