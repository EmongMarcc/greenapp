<div>
  <livewire:layout.navigation/>
    @livewire('layout.activityprofile', ['slug' => $slug ?? ''])
   <livewire:layout.footer/>
</div>
