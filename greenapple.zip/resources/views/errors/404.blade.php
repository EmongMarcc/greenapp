@extends('errors::layout')

@section('title', __('Server Error'))
@section('code', '404')
@section('message', __('Page not Found'))
