<div>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('YItyLKn')) {
    $componentId = $_instance->getRenderedChildComponentId('YItyLKn');
    $componentTag = $_instance->getRenderedChildComponentTagName('YItyLKn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YItyLKn');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('YItyLKn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.activityprofile', ['slug' => $slug ?? ''])->html();
} elseif ($_instance->childHasBeenRendered('SpFFm5m')) {
    $componentId = $_instance->getRenderedChildComponentId('SpFFm5m');
    $componentTag = $_instance->getRenderedChildComponentTagName('SpFFm5m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SpFFm5m');
} else {
    $response = \Livewire\Livewire::mount('layout.activityprofile', ['slug' => $slug ?? '']);
    $html = $response->html();
    $_instance->logRenderedChild('SpFFm5m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('0G0iaxA')) {
    $componentId = $_instance->getRenderedChildComponentId('0G0iaxA');
    $componentTag = $_instance->getRenderedChildComponentTagName('0G0iaxA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0G0iaxA');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('0G0iaxA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/activitypages.blade.php ENDPATH**/ ?>