<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="w-full flex h-full bg-gray-800" :class="{ 'overflow-hidden': isSideMenuOpen }">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dash.page.sidetoggle', [])->html();
} elseif ($_instance->childHasBeenRendered('T8INGRW')) {
    $componentId = $_instance->getRenderedChildComponentId('T8INGRW');
    $componentTag = $_instance->getRenderedChildComponentTagName('T8INGRW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T8INGRW');
} else {
    $response = \Livewire\Livewire::mount('dash.page.sidetoggle', []);
    $html = $response->html();
    $_instance->logRenderedChild('T8INGRW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="w-full">
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css">
                    <div class="flex flex-col flex-1 w-full overflow-y-auto">
                        <main class="">
                            <div class="grid mb-4 pb-10 px-8 mx-4 rounded-3xl bg-gray-100 border-4 border-green-400">
                                <div class="grid grid-cols-12 gap-6">
                                      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dash.page.posting', [])->html();
} elseif ($_instance->childHasBeenRendered('wXtq4xI')) {
    $componentId = $_instance->getRenderedChildComponentId('wXtq4xI');
    $componentTag = $_instance->getRenderedChildComponentTagName('wXtq4xI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wXtq4xI');
} else {
    $response = \Livewire\Livewire::mount('dash.page.posting', []);
    $html = $response->html();
    $_instance->logRenderedChild('wXtq4xI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </main>
                    </div>
                </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/dashboard.blade.php ENDPATH**/ ?>