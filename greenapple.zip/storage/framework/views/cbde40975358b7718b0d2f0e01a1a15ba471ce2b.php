<div>
  <style media="screen">
  .pt-\[17\%\] {
padding-top: 17%;
}
.mt-\[-10\%\] {
margin-top: -10%;
}
.pt-\[56\.25\%\] {
padding-top: 56.25%;
}
  </style>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('NLXl52u')) {
    $componentId = $_instance->getRenderedChildComponentId('NLXl52u');
    $componentTag = $_instance->getRenderedChildComponentTagName('NLXl52u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NLXl52u');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('NLXl52u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="bg-white justify-center mt-16">
      <div class="max-w-5xl mx-auto">
        <div>
          <div class="pt-6 pb-8 space-y-2 md:space-y-5">
            <ol class="flex justify-left gap-2" itemscope itemtype="https://schema.org/BreadcrumbList">
              <li class="text-center" itemprop="itemListElement" itemscope
                  itemtype="https://schema.org/ListItem">
                <a itemprop="item" href="<?php echo e(url('/')); ?>">
                <span itemprop="name">Home</span></a>
                <meta itemprop="position" content="1" />
              </li>
              <li class="text-center px-1 border-l-2 border-fuchsia-600" itemprop="itemListElement" itemscope
                  itemtype="https://schema.org/ListItem">
                <a itemprop="item"  href="<?php echo e(url('/offers')); ?>">
                <span itemprop="name">Tour Packages</span></a>
                <meta itemprop="position" content="2" />
              </li>
              <li class="text-center px-1 border-l-2 border-fuchsia-600" itemprop="itemListElement" itemscope
                  itemtype="https://schema.org/ListItem">
                <a itemprop="item" href="<?php echo e(url('/offer/tour/'.$touroffers[0]->offer_sitelink)); ?>">
                <span itemprop="name"><?php echo e($touroffers[0]->offer_sitelink); ?></span></a>
                <meta itemprop="position" content="3" />
              </li>
            </ol>
          </div>
          <div x-data="{ open: false }">

          <?php if ($touroffers ?? null): ?>
          <?php foreach ($touroffers ?? '' as $offer): ?>
            <div @click="open = false" class="bg-gray-300 bg-opacity-50 fixed w-full flex justify-center top-0 z-50" x-show="open"
            x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 transform scale-90"
             x-transition:enter-end="opacity-100 transform scale-100"
             x-transition:leave="transition ease-in duration-300"
             x-transition:leave-start="opacity-100 transform scale-100"
             x-transition:leave-end="opacity-0 transform scale-90">
              <img src="<?php echo e($offer->countryId); ?>" class="rounded-3xl shadow-2xl sm:w-1/2 w-full" alt="<?php echo e($offer->title); ?> tour">
            </div>
          <main class="relative container mx-auto bg-white px-4">
            <div class="relative -mx-4 top-0 pt-[17%] overflow-hidden">
              <img class="absolute inset-0 object-cover object-top w-full h-full filter blur" src="<?php echo e($offer->countryId); ?>" alt="Blur <?php echo e($offer->title); ?>" />

            </div>
            <div class="mt-[-10%] w-1/2 mx-auto">
              <div class="relative pt-[56.25%] overflow-hidden rounded-2xl">
                <img  @click="open = !open" class="w-full h-full absolute inset-0 object-cover cursor-pointer" src="<?php echo e($offer->countryId); ?>" alt="<?php echo e($offer->title); ?> img" />
              </div>
            </div>
            <article class="max-w-prose mx-auto py-8">
              <h1 class="text-2xl font-bold"><?php echo e($offer->title); ?></h1>
              <h2 class="mt-2 text-sm text-gray-500"><?php echo e($offer->datestart ?? ''); ?> - <?php echo e($offer->dateend ?? ''); ?></h2>
              <div>
                <?php echo $offer->description; ?>
                <ul>
                  <li><?php echo json_decode($offer->json_include)->flight ?? ''; ?></li>
                  <li><?php echo json_decode($offer->json_include)->hotel ?? ''; ?></li>
                  <li><?php echo json_decode($offer->json_include)->travelInsurance ?? ''; ?></li>
                  <li><?php echo json_decode($offer->json_include)->cityTours ?? ''; ?></li>
                  <li><?php echo json_decode($offer->json_include)->transfer ?? ''; ?></li>
                </ul>
              </div>
            </article>
          </main>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
      </div>
    </div>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('u9b6oFM')) {
    $componentId = $_instance->getRenderedChildComponentId('u9b6oFM');
    $componentTag = $_instance->getRenderedChildComponentTagName('u9b6oFM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('u9b6oFM');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('u9b6oFM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   <script type="application/ld+json">
  {
    "@context":"https://schema.org",
    "@graph":[
      {
        "@type":"Organization",
        "@id":"https://greenappletravel.ae/#organization",
        "name":"GreenApple Travel and Tourism LLC",
        "url":"https://greenappletravel.ae/",
        "sameAs":
        [
          "https://www.facebook.com/greenappledxb/",
          "https://instagram.com/greenappledxb/",
          "https://twitter.com/greenappledxb/"
        ],
        "logo":
        {
          "@type":"ImageObject",
          "@id":"https://www.greenappletravel.ae/#logo",
          "inLanguage":"en-US",
          "url":"<?php echo e($touroffers[0]->tour_img); ?>", "contentUrl":"<?php echo e($touroffers[0]->tour_img); ?>",
          "width":60,
          "height":43,
          "caption":"<?php echo e($touroffers[0]->title); ?>"
        },
        "image":{"@id":"https://greenappletravel.ae/#logo"}},
      {
        "@type":"WebSite",
        "@id":"https://greenappletravel.ae/#website",
        "url":"https://greenappletravel.ae/",
        "name":"<?php echo e($touroffers[0]->title); ?>",
        "description":"GreenApple Travel and Tourism",
        "publisher":
        {
          "@id":"https://greenappletravel.ae/#organization"
        },
        "potentialAction":
        [
          {
           "@type":"SearchAction",
           "target":
            {
            "@type":"EntryPoint",
            "urlTemplate":"https://greenappletravel.ae/?s={search_term_string}"
            },
            "query-input":"required name=search_term_string"}],
        "inLanguage":"en-US"
      },
      {
        "@type":"ImageObject",
        "@id":"https://greenappletravel.ae/#primaryimage",
        "inLanguage":"en-US",
        "url":"<?php echo e($touroffers[0]->tour_img); ?>",
        "contentUrl":"<?php echo e($touroffers[0]->tour_img); ?>",
        "width":940,
        "height":788
      },{
        "@type":"WebPage",
        "@id":"https://greenappletravel.ae/#webpage",
        "url":"https://greenappletravel.ae/",
        "name":"<?php echo e($touroffers[0]->title); ?>",
        "isPartOf":
        {
          "@id":"https://greenappletravel.ae/#website"
        },
        "primaryImageOfPage":
        {
          "@id":"https://greenappletravel.ae/#primaryimage"
        },
        "datePublished":"2017-08-26T09:05:12+00:00",
        "dateModified":"2021-10-01T20:13:12+00:00",
        "description":"<?php echo e($touroffers[0]->title); ?>",
        "breadcrumb":{"@id":"https://greenappletravel.ae/#breadcrumb"},
        "inLanguage":"en-US",
        "potentialAction":[{"@type":"ReadAction",
                            "target":["https://greenappletravel.ae/"]}]}
    ]
  }
</script>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/offerpage.blade.php ENDPATH**/ ?>