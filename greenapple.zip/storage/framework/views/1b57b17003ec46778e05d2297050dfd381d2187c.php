<div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('AkWCkhV')) {
    $componentId = $_instance->getRenderedChildComponentId('AkWCkhV');
    $componentTag = $_instance->getRenderedChildComponentTagName('AkWCkhV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AkWCkhV');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('AkWCkhV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="mt-10 pt-10">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.contacts', [])->html();
} elseif ($_instance->childHasBeenRendered('f5Qyryp')) {
    $componentId = $_instance->getRenderedChildComponentId('f5Qyryp');
    $componentTag = $_instance->getRenderedChildComponentTagName('f5Qyryp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('f5Qyryp');
} else {
    $response = \Livewire\Livewire::mount('layout.contacts', []);
    $html = $response->html();
    $_instance->logRenderedChild('f5Qyryp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="bg-gray-100 w-full overflow-hidden">
  <script src="https://apps.elfsight.com/p/platform.js" defer></script>
  <div class="elfsight-app-b7fa309a-6da8-46c8-803e-677e7ae1236e"></div>
</div>
</div>
<!-- l i ve wire :lay out.body/ -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('T716fgd')) {
    $componentId = $_instance->getRenderedChildComponentId('T716fgd');
    $componentTag = $_instance->getRenderedChildComponentTagName('T716fgd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T716fgd');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('T716fgd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/contacts.blade.php ENDPATH**/ ?>