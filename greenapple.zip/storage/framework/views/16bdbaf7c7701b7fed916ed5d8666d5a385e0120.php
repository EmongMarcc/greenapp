<div>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('5bZ3iRf')) {
    $componentId = $_instance->getRenderedChildComponentId('5bZ3iRf');
    $componentTag = $_instance->getRenderedChildComponentTagName('5bZ3iRf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5bZ3iRf');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('5bZ3iRf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('page.travelrestriction', [])->html();
} elseif ($_instance->childHasBeenRendered('ot99K3S')) {
    $componentId = $_instance->getRenderedChildComponentId('ot99K3S');
    $componentTag = $_instance->getRenderedChildComponentTagName('ot99K3S');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ot99K3S');
} else {
    $response = \Livewire\Livewire::mount('page.travelrestriction', []);
    $html = $response->html();
    $_instance->logRenderedChild('ot99K3S', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('QKCbgFT')) {
    $componentId = $_instance->getRenderedChildComponentId('QKCbgFT');
    $componentTag = $_instance->getRenderedChildComponentTagName('QKCbgFT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QKCbgFT');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('QKCbgFT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/travrestrict.blade.php ENDPATH**/ ?>