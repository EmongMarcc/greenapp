<div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('OKU9s9q')) {
    $componentId = $_instance->getRenderedChildComponentId('OKU9s9q');
    $componentTag = $_instance->getRenderedChildComponentTagName('OKU9s9q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OKU9s9q');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('OKU9s9q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="bg-white mt-10 pt-10">
<div class="w-full overflow-hidden">
  <div class="md:px-6 py-8">
    <ol class="flex justify-left gap-2" itemscope itemtype="https://schema.org/BreadcrumbList">
      <li class="text-center" itemprop="itemListElement" itemscope
          itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="<?php echo e(url('/')); ?>">
        <span itemprop="name">Home</span></a>
        <meta itemprop="position" content="1" />
      </li>
      <li class="text-center px-1 border-l-2 border-fuchsia-600" itemprop="itemListElement" itemscope
          itemtype="https://schema.org/ListItem">
        <a itemprop="item"  href="<?php echo e(url('/about-us')); ?>">
        <span itemprop="name">About</span></a>
        <meta itemprop="position" content="2" />
      </li>
    </ol>
    <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl md:text-[4rem] md:leading-[3.5rem]">About us</h1>
          <div class="container flex justify-between mx-auto">
              <div class="w-full">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.cards', [])->html();
} elseif ($_instance->childHasBeenRendered('Kq5HAL2')) {
    $componentId = $_instance->getRenderedChildComponentId('Kq5HAL2');
    $componentTag = $_instance->getRenderedChildComponentTagName('Kq5HAL2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Kq5HAL2');
} else {
    $response = \Livewire\Livewire::mount('layout.cards', []);
    $html = $response->html();
    $_instance->logRenderedChild('Kq5HAL2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('page.news', [])->html();
} elseif ($_instance->childHasBeenRendered('bEZWnof')) {
    $componentId = $_instance->getRenderedChildComponentId('bEZWnof');
    $componentTag = $_instance->getRenderedChildComponentTagName('bEZWnof');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bEZWnof');
} else {
    $response = \Livewire\Livewire::mount('page.news', []);
    $html = $response->html();
    $_instance->logRenderedChild('bEZWnof', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              </div>
          </div>
      </div>
</div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('afff0QI')) {
    $componentId = $_instance->getRenderedChildComponentId('afff0QI');
    $componentTag = $_instance->getRenderedChildComponentTagName('afff0QI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('afff0QI');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('afff0QI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/about.blade.php ENDPATH**/ ?>