<a href="/">
    <img class="w-32 h-full" src="<?php echo e(asset('images/gattlogo.png')); ?>" alt="Green Apple Logo">
</a>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>