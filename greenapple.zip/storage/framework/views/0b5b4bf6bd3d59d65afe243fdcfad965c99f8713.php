<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Page not Found')); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\greenapple\resources\views/errors/404.blade.php ENDPATH**/ ?>