<div class="flex">
  <?php if (InstagramBasicFeed::getAllUserMedias()): ?>
    <?php $__currentLoopData = InstagramBasicFeed::getAllUserMedias(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shadow-lg bg-gray-500 bg-opacity-50 transition duration-150 ease-in-out glow-effect">
      <?php if ($media->media_type === "VIDEO"): ?>
        <button class="w-40" type="button" @click="open = '<?php echo $media->permalink.'embed' ?>'">
        <img class="w-40 h-40 object-cover" rel="nofollow" src="<?php echo e($media->thumbnail_url); ?>" alt="<?php echo e(substr($media->caption ?? 'insta_greenapple', 0, 20)); ?>">
        </button>
        <?php else: ?>
          <button class="w-40" type="button" @click="open = '<?php echo $media->permalink.'embed' ?>'">
          <img class="w-40 h-40 object-cover" rel="nofollow" src="<?php echo e($media->media_url); ?>" alt="<?php echo e(substr($media->caption ?? 'insta_greenapple', 0, 20)); ?>">

        </button>
      <?php endif; ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/vendor/instagram-basic-feed/instagram-post.blade.php ENDPATH**/ ?>