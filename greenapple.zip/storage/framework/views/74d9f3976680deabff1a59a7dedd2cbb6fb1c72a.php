<div>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('QTgz19A')) {
    $componentId = $_instance->getRenderedChildComponentId('QTgz19A');
    $componentTag = $_instance->getRenderedChildComponentTagName('QTgz19A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QTgz19A');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('QTgz19A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.touractivities', [])->html();
} elseif ($_instance->childHasBeenRendered('qJ6TOY9')) {
    $componentId = $_instance->getRenderedChildComponentId('qJ6TOY9');
    $componentTag = $_instance->getRenderedChildComponentTagName('qJ6TOY9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qJ6TOY9');
} else {
    $response = \Livewire\Livewire::mount('layout.touractivities', []);
    $html = $response->html();
    $_instance->logRenderedChild('qJ6TOY9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('uhsAcC1')) {
    $componentId = $_instance->getRenderedChildComponentId('uhsAcC1');
    $componentTag = $_instance->getRenderedChildComponentTagName('uhsAcC1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uhsAcC1');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('uhsAcC1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/touractivity.blade.php ENDPATH**/ ?>