<div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.navigation', [])->html();
} elseif ($_instance->childHasBeenRendered('OTOOAd0')) {
    $componentId = $_instance->getRenderedChildComponentId('OTOOAd0');
    $componentTag = $_instance->getRenderedChildComponentTagName('OTOOAd0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OTOOAd0');
} else {
    $response = \Livewire\Livewire::mount('layout.navigation', []);
    $html = $response->html();
    $_instance->logRenderedChild('OTOOAd0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="bg-white mt-10 pt-10">
<div class="w-full overflow-hidden">
  <div wire:init="loadPosts" class="md:px-6 py-8">
    <ol class="flex justify-left gap-2" itemscope itemtype="https://schema.org/BreadcrumbList">
      <li class="text-center" itemprop="itemListElement" itemscope
          itemtype="https://schema.org/ListItem">
        <a itemprop="item" href="<?php echo e(url('/')); ?>">
        <span itemprop="name">Home</span></a>
        <meta itemprop="position" content="1" />
      </li>
      <li class="text-center px-1 border-l-2 border-fuchsia-600" itemprop="itemListElement" itemscope
          itemtype="https://schema.org/ListItem">
        <a itemprop="item"  href="<?php echo e(url('/travelrestrictions')); ?>">
        <span itemprop="name">Travel Restrictions</span></a>
        <meta itemprop="position" content="2" />
      </li>
    </ol>
    <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl md:text-[4rem] md:leading-[3.5rem]">International Travel Update</h1>
          <div class="container flex justify-between mx-auto">
              <div class="w-full">

              </div>
          </div>
      </div>
</div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layout.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('rAPiMXk')) {
    $componentId = $_instance->getRenderedChildComponentId('rAPiMXk');
    $componentTag = $_instance->getRenderedChildComponentTagName('rAPiMXk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rAPiMXk');
} else {
    $response = \Livewire\Livewire::mount('layout.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('rAPiMXk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\greenapple\resources\views/livewire/page/restrictions.blade.php ENDPATH**/ ?>